# CoinPortracker

**Portfólio cripto local-first, somente leitura e sem backend próprio.** O objetivo do CoinPortracker é consolidar saldos de endereços públicos, transações on-chain, custos informados pelo usuário, taxas identificadas e registros DeFi em uma interface privada por padrão.

> Estado do projeto: **MVP funcional / cobertura parcial**. A aplicação consulta saldos e uma janela recente de transações em redes selecionadas. Ela não é, ainda, um indexador universal de blockchain nem um sistema de contabilidade fiscal.

## Início rápido

Não há etapa de build nem dependências de runtime. Sirva a pasta por HTTP (módulos JavaScript do navegador não funcionam corretamente quando o HTML é aberto como `file://`):

```bash
python3 -m http.server 8080
```

Abra `http://localhost:8080`.

Também é possível publicar a pasta na raiz de um repositório GitHub. Em **Settings → Pages**, selecione **GitHub Actions** como fonte de publicação. O workflow em `.github/workflows/pages.yml` publica o site automaticamente a cada push na branch `main`.

## O que está implementado

- Dashboard com valor consolidado, alocação, índice heurístico de concentração/diversificação e histórico de snapshots.
- Cadastro de múltiplas carteiras públicas; nenhuma chave privada, seed phrase ou assinatura é solicitada.
- Redes: Bitcoin, Ethereum, Base, Arbitrum One, Optimism, Polygon PoS e Solana.
- Saldos nativos; tokens ERC-20 via Blockscout; tokens SPL via RPC Solana (USDC e USDT reconhecidos, demais tokens apresentados pelo identificador abreviado da mint).
- Transações recentes de Bitcoin, EVM e Solana com data, horário, tipo, quantidade, taxa quando disponibilizada, hash e link para explorer.
- Pesquisa e filtros de transações por texto, rede, tipo e data.
- Registro manual de aquisições com quantidade, preço unitário, data e taxa informada; separação entre custo sem taxa e custo com taxa.
- Soma de taxas que aparecem nas transações efetivamente indexadas.
- Posições e recompensas DeFi manuais, com protocolo, rede, ativo, quantidade, data/hora, bloco/slot e hash opcional. Toggle para incluir posições DeFi no saldo total.
- IndexedDB, pedido de persistência ao navegador, exportação/importação JSON e opção de apagar os dados locais.
- Sem conta de usuário, backend CoinPortracker, cookies de analytics, pixels ou scripts de publicidade.

## Arquitetura

```text
index.html / styles.css
        │
        └── src/main.js ────────────── UI, navegação, eventos e métricas
               ├── src/db.js ─────── IndexedDB, backup e persistência
               ├── src/providers.js ─ mempool.space, Blockscout e Solana RPC
               ├── src/market.js ──── CoinGecko + fallback de market data Binance
               └── src/analytics.js ─ agregação, saúde e variação de snapshots
```

O navegador consulta diretamente os serviços externos. Endereços, custos manuais, cache e snapshots são guardados no IndexedDB do dispositivo. Não existe um servidor CoinPortracker intermediando as requisições.

## Provedores e cobertura

| Fonte | Uso | Observação |
|---|---|---|
| [mempool.space API](https://mempool.space/docs/api/rest) | Saldo, UTXOs e transações Bitcoin | Rate limit; carregamento inicial limitado a até quatro páginas de transações confirmadas. |
| [Blockscout API v2](https://docs.blockscout.com/devs/apis) | Saldo nativo, tokens, transações e transferências em redes EVM selecionadas | A cobertura e a disponibilidade variam por instância; a versão atual busca as páginas recentes retornadas por padrão. |
| [Solana JSON-RPC](https://solana.com/docs/rpc) | Saldo SOL, contas SPL e assinaturas/transações recentes | RPC público compartilhado, sem SLA; consulta até 60 assinaturas e detalha até 30 transações nesta versão. |
| [CoinGecko API](https://docs.coingecko.com/) | Cotação de ativos conhecidos | Uma chave Demo gratuita pode ser necessária conforme as regras atuais do plano. A chave inserida fica no IndexedDB local e é enviada somente ao CoinGecko. Como as configurações entram no backup, o JSON exportado também pode conter essa chave. |
| [Binance public market data](https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md) | Fallback de preço para pares líquidos | Endpoint público sem autenticação; cobre apenas os pares disponíveis. |
| [Frankfurter](https://www.frankfurter.app/) | Conversão USD/BRL para preços provenientes de explorers | Serviço externo; se indisponível, o app não inventa uma taxa de câmbio. |

## Limites que devem ser entendidos antes de usar

### 1. Uma transação recebida não prova uma compra

Uma entrada pode ser uma transferência entre carteiras próprias, saque de exchange, pagamento, airdrop, recompensa ou compra. A blockchain não registra necessariamente quanto foi pago em BRL/USD na aquisição. Por isso, o custo de aquisição é informado manualmente nesta versão. O valor total e o P/L só são confiáveis na medida em que os registros de aquisição, vendas e transferências tenham sido reconciliados.

### 2. P/L histórico não é retorno ajustado por fluxo de caixa

O gráfico começa no primeiro snapshot local, não na primeira transação da carteira. Encontrar a transação mais antiga não basta para reconstruir o valor histórico da carteira: seria necessário indexar toda a atividade, identificar transferências internas, reconstruir posições históricas e obter preços históricos de cada ativo nos instantes relevantes. Os P/L de 1h, 24h, 7d e 1a usam a variação entre snapshots disponíveis e **não** descontam aportes/saques. Ainda não são uma série de retorno time-weighted nem uma apuração fiscal.

### 3. DeFi não possui um formato universal

O saldo em protocolos DeFi pode estar representado por tokens LP, recibos de staking, posições concentradas, collateral, dívida, rewards pendentes ou dados internos de contratos. A versão atual permite registrar esses itens manualmente e incluí-los no saldo pelo toggle. Detecção automática exige adaptadores e decodificadores específicos por protocolo/rede; não se deve interpretar a aba como varredura DeFi completa.

### 4. “Todas as transações” depende de indexadores e paginação

Nós RPC públicos não oferecem, em geral, uma API universal de histórico por endereço. Esta versão usa indexadores disponíveis e limita algumas consultas para respeitar os serviços gratuitos. A primeira transação retornada é apenas a mais antiga entre os dados efetivamente consultados.

### 5. Privacidade não significa invisibilidade de rede

O CoinPortracker não recebe os endereços em um backend próprio. Entretanto, o provedor consultado recebe o endereço público solicitado, o IP e metadados normais da conexão. O host do GitHub Pages também recebe requisições HTTP quando o site é hospedado nele. Não insira dados secretos: endereços blockchain são públicos, mas continuam sendo dados potencialmente correlacionáveis.

## Segurança e backup

- Nunca informe seed phrase, chave privada, keystore, senha ou código 2FA.
- Os backups JSON podem conter todos os endereços monitorados, histórico cacheado e registros financeiros manuais. A importação mescla/substitui registros que tenham o mesmo ID, sem apagar registros locais ausentes no backup. Trate o arquivo como dado privado.
- Limpar dados do navegador pode apagar o IndexedDB. Exporte backups periodicamente e teste a restauração.
- A solicitação de armazenamento persistente depende do navegador e pode ser negada.
- O projeto é uma ferramenta de visualização; não assina, envia ou executa transações.

## Próximos módulos recomendados

1. Indexação paginada e incremental persistente, com checkpoint por carteira e rede.
2. Importação de CSVs de exchanges e reconciliação de transferências internas.
3. Livro-razão de lotes (FIFO / custo médio configurável), vendas, swaps, airdrops e taxas por ativo.
4. Histórico de preço por timestamp e métricas de retorno ajustadas a fluxos de caixa.
5. Adaptadores DeFi por protocolo (staking, lending, LPs e rewards) com proveniência do bloco/evento.
6. Mais redes EVM, TON, XRP Ledger, Stellar, Tron, Cosmos SDK e demais famílias de blockchain.
7. Testes automatizados, verificação de endereço/chain-id e limites de taxa configuráveis.

## Licença

MIT. Consulte `LICENSE`.
