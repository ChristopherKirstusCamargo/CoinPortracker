const BTC_API = 'https://mempool.space/api';
const SOL_RPC = 'https://api.mainnet.solana.com';
export const NETWORKS = {
  bitcoin: { name: 'Bitcoin', symbol: 'BTC', chain: 'UTXO', explorer: 'https://mempool.space/address/' },
  ethereum: { name: 'Ethereum', symbol: 'ETH', chain: 'EVM', host: 'https://eth.blockscout.com', explorer: 'https://eth.blockscout.com/address/' },
  base: { name: 'Base', symbol: 'ETH', chain: 'EVM', host: 'https://base.blockscout.com', explorer: 'https://base.blockscout.com/address/' },
  arbitrum: { name: 'Arbitrum One', symbol: 'ETH', chain: 'EVM', host: 'https://arbitrum.blockscout.com', explorer: 'https://arbitrum.blockscout.com/address/' },
  optimism: { name: 'Optimism', symbol: 'ETH', chain: 'EVM', host: 'https://optimism.blockscout.com', explorer: 'https://optimism.blockscout.com/address/' },
  polygon: { name: 'Polygon PoS', symbol: 'POL', chain: 'EVM', host: 'https://polygon.blockscout.com', explorer: 'https://polygon.blockscout.com/address/' },
  solana: { name: 'Solana', symbol: 'SOL', chain: 'SOL', explorer: 'https://explorer.solana.com/address/' }
};

const COINGECKO_IDS = {
  BTC: 'bitcoin', ETH: 'ethereum', SOL: 'solana', USDT: 'tether', USDC: 'usd-coin',
  POL: 'polygon-ecosystem-token', MATIC: 'matic-network', BNB: 'binancecoin', XRP: 'ripple',
  XLM: 'stellar', LINK: 'chainlink', UNI: 'uniswap', DOGE: 'dogecoin', ADA: 'cardano',
  DOT: 'polkadot', AVAX: 'avalanche-2', LTC: 'litecoin', TRX: 'tron'
};

async function jsonFetch(url, options = {}, timeoutMs = 18000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal, headers: { Accept: 'application/json', ...(options.headers || {}) } });
    if (!response.ok) throw new Error(`Provedor respondeu HTTP ${response.status}.`);
    return await response.json();
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Tempo limite excedido ao consultar o provedor.');
    throw error;
  } finally { clearTimeout(timer); }
}

function validateAddress(wallet) {
  const { network, address } = wallet;
  if (network === 'bitcoin' && !/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{20,90}$/.test(address)) throw new Error('Formato de endereço Bitcoin inválido.');
  if (['ethereum','base','arbitrum','optimism','polygon'].includes(network) && !/^0x[a-fA-F0-9]{40}$/.test(address)) throw new Error('Formato de endereço EVM inválido.');
  if (network === 'solana' && !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) throw new Error('Formato de endereço Solana inválido.');
}

function txRecord({ id, network, timestamp, type, asset, amount, fee = 0, feeAsset, from, to, block, status = 'confirmed', walletId }) {
  return { id: `${network}:${id}`, txid: id, network, timestamp: timestamp ? Number(timestamp) * (Number(timestamp) < 1e12 ? 1000 : 1) : null, type, asset, amount: Number(amount || 0), fee: Number(fee || 0), feeAsset, from, to, block: block ?? null, status, walletId };
}

async function fetchBitcoin(wallet) {
  const base = `${BTC_API}/address/${encodeURIComponent(wallet.address)}`;
  const [summary, utxos, firstPage] = await Promise.all([
    jsonFetch(base), jsonFetch(`${base}/utxo`), jsonFetch(`${base}/txs/chain`)
  ]);
  const confirmed = summary.chain_stats || {};
  const pending = summary.mempool_stats || {};
  const sats = Number(confirmed.funded_txo_sum || 0) - Number(confirmed.spent_txo_sum || 0) + Number(pending.funded_txo_sum || 0) - Number(pending.spent_txo_sum || 0);
  let rawTxs = Array.isArray(firstPage) ? [...firstPage] : [];
  let cursor = rawTxs.at(-1)?.txid;
  // Deliberate bounded scan: keeps shared public infrastructure usable. Users can refresh later.
  for (let page = 1; page < 4 && rawTxs.length && cursor; page++) {
    const next = await jsonFetch(`${base}/txs/chain?after_txid=${encodeURIComponent(cursor)}`);
    if (!Array.isArray(next) || next.length === 0) break;
    rawTxs.push(...next);
    cursor = next.at(-1)?.txid;
  }
  const transactions = rawTxs.map(tx => {
    const received = (tx.vout || []).filter(v => v.scriptpubkey_address === wallet.address).reduce((sum, v) => sum + Number(v.value || 0), 0);
    const sent = (tx.vin || []).filter(v => v.prevout?.scriptpubkey_address === wallet.address).reduce((sum, v) => sum + Number(v.prevout?.value || 0), 0);
    const status = tx.status || {};
    return txRecord({ id: tx.txid, network: 'bitcoin', timestamp: status.block_time, type: sent > received ? 'out' : received > sent ? 'in' : 'self', asset: 'BTC', amount: Math.abs(received - sent) / 1e8, fee: Number(tx.fee || 0) / 1e8, feeAsset: 'BTC', from: (tx.vin || []).map(v => v.prevout?.scriptpubkey_address).filter(Boolean).join(', '), to: (tx.vout || []).map(v => v.scriptpubkey_address).filter(Boolean).join(', '), block: status.block_height, status: status.confirmed ? 'confirmed' : 'pending', walletId: wallet.id });
  });
  return {
    walletId: wallet.id, fetchedAt: Date.now(), network: 'bitcoin', status: 'ok',
    assets: [{ symbol: 'BTC', name: 'Bitcoin', amount: sats / 1e8, priceUsd: null, priceBrl: null, source: 'mempool.space', network: 'Bitcoin' }],
    transactions, fees: transactions.reduce((sum, tx) => sum + tx.fee, 0), oldestTimestamp: transactions.map(t => t.timestamp).filter(Boolean).sort((a,b)=>a-b)[0] || null,
    meta: { scannedTransactions: transactions.length, utxoCount: utxos.length, note: 'Histórico limitado às páginas consultadas. O endpoint público aplica rate limit.' }
  };
}

async function fetchEvm(wallet) {
  const net = NETWORKS[wallet.network];
  const base = `${net.host}/api/v2/addresses/${wallet.address}`;
  const [summary, balances, txPage, transfers] = await Promise.all([
    jsonFetch(base), jsonFetch(`${base}/token-balances`), jsonFetch(`${base}/transactions`), jsonFetch(`${base}/token-transfers`)
  ]);
  const assets = [{ symbol: net.symbol, name: net.name === 'Polygon PoS' ? 'POL' : 'Ether', amount: Number(summary.coin_balance || 0) / 1e18, priceUsd: summary.exchange_rate ? Number(summary.exchange_rate) : null, priceBrl: null, source: 'Blockscout', network: net.name }];
  for (const item of (Array.isArray(balances) ? balances : [])) {
    const token = item.token || {};
    const decimals = Math.min(36, Math.max(0, Number(token.decimals || 0)));
    const amount = Number(item.value || 0) / (10 ** decimals);
    if (!Number.isFinite(amount) || amount === 0) continue;
    assets.push({ symbol: String(token.symbol || 'TOKEN').toUpperCase(), name: token.name || token.symbol || 'Token', amount, priceUsd: token.exchange_rate != null ? Number(token.exchange_rate) : null, priceBrl: null, source: 'Blockscout', network: net.name, contract: token.address_hash });
  }
  const raw = new Map();
  for (const tx of (txPage.items || [])) raw.set(tx.hash, tx);
  const transactions = [];
  for (const tx of raw.values()) {
    const feeWei = BigInt(tx.gas_used || 0) * BigInt(tx.gas_price || 0);
    transactions.push(txRecord({ id: tx.hash, network: wallet.network, timestamp: tx.timestamp ? Date.parse(tx.timestamp) : null, type: tx.from?.hash?.toLowerCase() === wallet.address.toLowerCase() ? 'out' : 'in', asset: net.symbol, amount: Number(tx.value || 0) / 1e18, fee: Number(feeWei) / 1e18, feeAsset: net.symbol, from: tx.from?.hash, to: tx.to?.hash, block: tx.block, status: tx.status === 'ok' ? 'confirmed' : tx.status || 'unknown', walletId: wallet.id }));
  }
  for (const transfer of (transfers.items || [])) {
    const token = transfer.token || {};
    const decimals = Math.min(36, Math.max(0, Number(token.decimals || 0)));
    const amount = Number(transfer.total?.value || 0) / (10 ** decimals);
    transactions.push(txRecord({ id: `${transfer.transaction_hash}:${transfer.log_index}`, network: wallet.network, timestamp: transfer.timestamp ? Date.parse(transfer.timestamp) : null, type: transfer.from?.hash?.toLowerCase() === wallet.address.toLowerCase() ? 'out' : 'in', asset: String(token.symbol || 'TOKEN').toUpperCase(), amount, fee: 0, from: transfer.from?.hash, to: transfer.to?.hash, block: transfer.block, walletId: wallet.id }));
  }
  const unique = [...new Map(transactions.map(tx => [tx.id, tx])).values()].sort((a,b) => (b.timestamp || 0) - (a.timestamp || 0));
  return {
    walletId: wallet.id, fetchedAt: Date.now(), network: wallet.network, status: 'ok', assets, transactions: unique,
    fees: unique.filter(t => t.feeAsset).reduce((sum,t)=>sum+t.fee,0), oldestTimestamp: unique.map(t=>t.timestamp).filter(Boolean).sort((a,b)=>a-b)[0] || null,
    meta: { scannedTransactions: unique.length, note: 'Blockscout retorna páginas recentes. O histórico completo requer paginação adicional e pode variar por rede.' }
  };
}

async function solanaRpc(method, params) {
  const payload = await jsonFetch(SOL_RPC, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }) });
  if (payload.error) throw new Error(payload.error.message || 'Erro no RPC Solana.');
  return payload.result;
}

async function fetchSolana(wallet) {
  const address = wallet.address;
  const [balance, legacyTokenAccounts, token2022Accounts, signatures] = await Promise.all([
    solanaRpc('getBalance', [address, { commitment: 'confirmed' }]),
    solanaRpc('getTokenAccountsByOwner', [address, { programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA' }, { encoding: 'jsonParsed', commitment: 'confirmed' }]),
    solanaRpc('getTokenAccountsByOwner', [address, { programId: 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb' }, { encoding: 'jsonParsed', commitment: 'confirmed' }]),
    solanaRpc('getSignaturesForAddress', [address, { limit: 60, commitment: 'confirmed' }])
  ]);
  const tokenAccounts = [...(legacyTokenAccounts.value || []), ...(token2022Accounts.value || [])];
  const assets = [{ symbol: 'SOL', name: 'Solana', amount: Number(balance.value || 0) / 1e9, priceUsd: null, priceBrl: null, source: 'Solana RPC', network: 'Solana' }];
  const stableMints = { 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v': { symbol:'USDC', name:'USD Coin' }, 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB': { symbol:'USDT', name:'Tether' } };
  for (const item of tokenAccounts) {
    const info = item.account?.data?.parsed?.info;
    const token = info?.tokenAmount;
    const amount = Number(token?.uiAmountString ?? token?.uiAmount ?? 0);
    if (!amount) continue;
    const known = stableMints[info.mint];
    assets.push({ symbol: known?.symbol || `${info.mint.slice(0,4)}…`, name: known?.name || `SPL ${info.mint.slice(0,8)}…`, amount, priceUsd: known ? 1 : null, priceBrl: null, source: 'Solana RPC', network: 'Solana', contract: info.mint });
  }
  const sigs = (signatures || []).slice(0, 30);
  const txs = [];
  for (let i=0; i<sigs.length; i+=4) {
    const batch = await Promise.all(sigs.slice(i,i+4).map(async sig => {
      try { return await solanaRpc('getTransaction', [sig.signature, { encoding:'jsonParsed', maxSupportedTransactionVersion:0, commitment:'confirmed' }]); }
      catch { return null; }
    }));
    for (let j=0; j<batch.length; j++) {
      const detail = batch[j];
      const sig = sigs[i+j];
      if (!detail) continue;
      const message = detail.transaction?.message;
      const keys = (message?.accountKeys || []).map(k => typeof k === 'string' ? k : k.pubkey);
      const idx = keys.indexOf(address);
      const pre = idx >= 0 ? Number(detail.meta?.preBalances?.[idx] || 0) : 0;
      const post = idx >= 0 ? Number(detail.meta?.postBalances?.[idx] || 0) : 0;
      const isFeePayer = keys[0] === address;
      const feeLamports = isFeePayer ? Number(detail.meta?.fee || 0) : 0;
      const delta = (post - pre + feeLamports) / 1e9;
      txs.push(txRecord({ id:`${sig.signature}:SOL`, network:'solana', timestamp:detail.blockTime || sig.blockTime, type:delta < 0 ? 'out' : delta > 0 ? 'in' : 'self', asset:'SOL', amount:Math.abs(delta), fee:feeLamports/1e9, feeAsset:'SOL', from:address, to:'—', block:detail.slot, status:'confirmed', walletId:wallet.id }));
      const tokenChanges = new Map();
      for (const token of (detail.meta?.preTokenBalances || [])) {
        if (token.owner !== address) continue;
        const entry=tokenChanges.get(token.mint)||{pre:0,post:0,decimals:Number(token.uiTokenAmount?.decimals||0)};
        entry.pre += Number(token.uiTokenAmount?.amount||0)/(10**entry.decimals); tokenChanges.set(token.mint,entry);
      }
      for (const token of (detail.meta?.postTokenBalances || [])) {
        if (token.owner !== address) continue;
        const entry=tokenChanges.get(token.mint)||{pre:0,post:0,decimals:Number(token.uiTokenAmount?.decimals||0)};
        entry.post += Number(token.uiTokenAmount?.amount||0)/(10**entry.decimals); tokenChanges.set(token.mint,entry);
      }
      for (const [mint, change] of tokenChanges) {
        const tokenDelta=change.post-change.pre;
        if (Math.abs(tokenDelta)<1e-12) continue;
        const known=stableMints[mint];
        txs.push(txRecord({ id:`${sig.signature}:${mint}`, network:'solana', timestamp:detail.blockTime||sig.blockTime, type:tokenDelta<0?'out':'in', asset:known?.symbol||`${mint.slice(0,4)}…`, amount:Math.abs(tokenDelta), fee:0, from:address, to:'—', block:detail.slot, status:'confirmed', walletId:wallet.id }));
      }
    }
  }
  return {
    walletId: wallet.id, fetchedAt: Date.now(), network: 'solana', status: 'ok', assets, transactions: txs.sort((a,b)=>(b.timestamp||0)-(a.timestamp||0)),
    fees: txs.reduce((s,t)=>s+t.fee,0), oldestTimestamp: txs.map(t=>t.timestamp).filter(Boolean).sort((a,b)=>a-b)[0] || null,
    meta: { scannedTransactions: txs.length, signaturesAvailable: signatures?.length || 0, note: 'RPC público: consulta limitada às assinaturas recentes; histórico completo exige indexador dedicado.' }
  };
}

export async function fetchWallet(wallet) {
  validateAddress(wallet);
  if (wallet.network === 'bitcoin') return fetchBitcoin(wallet);
  if (wallet.network === 'solana') return fetchSolana(wallet);
  return fetchEvm(wallet);
}

export function coinGeckoId(symbol) { return COINGECKO_IDS[String(symbol || '').toUpperCase()] || null; }
export { validateAddress };
