import { coinGeckoId } from './providers.js';

const BINANCE_SYMBOLS = {
  BTC:'BTCUSDT', ETH:'ETHUSDT', SOL:'SOLUSDT', USDC:'USDCUSDT',
  POL:'POLUSDT', BNB:'BNBUSDT', XRP:'XRPUSDT', XLM:'XLMUSDT',
  LINK:'LINKUSDT', UNI:'UNIUSDT', DOGE:'DOGEUSDT', ADA:'ADAUSDT', DOT:'DOTUSDT',
  AVAX:'AVAXUSDT', LTC:'LTCUSDT', TRX:'TRXUSDT'
};

async function safeJson(url, headers = {}) {
  const response = await fetch(url, { headers: { Accept:'application/json', ...headers } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

export async function fetchMarketPrices(assets, currency = 'brl', apiKey = '') {
  const symbols = [...new Set(assets.map(a => String(a.symbol || '').toUpperCase()).filter(Boolean))];
  const ids = [...new Set(symbols.map(coinGeckoId).filter(Boolean))];
  const quotes = {};
  if (ids.length) {
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(ids.join(','))}&vs_currencies=brl,usd&include_24hr_change=true`;
    try {
      const data = await safeJson(url, apiKey ? { 'x-cg-demo-api-key': apiKey } : {});
      for (const [id, value] of Object.entries(data)) quotes[id] = { brl:value.brl ?? null, usd:value.usd ?? null, change24h:value.brl_24h_change ?? value.usd_24h_change ?? null };
    } catch { /* public Binance endpoint is used as a no-key fallback where available */ }
  }

  // Binance's market-data-only host provides public spot quotes without an API key.
  const pairs = [...new Set(symbols.map(symbol => BINANCE_SYMBOLS[symbol]).filter(Boolean))];
  let binanceQuotes = {};
  if (pairs.length) {
    try {
      const symbolsParam = encodeURIComponent(JSON.stringify(pairs));
      const data = await safeJson(`https://data-api.binance.vision/api/v3/ticker/price?symbols=${symbolsParam}`);
      binanceQuotes = Object.fromEntries((Array.isArray(data) ? data : [data]).map(item => [item.symbol, Number(item.price)]));
    } catch {
      // An unavailable pair must not prevent valid symbols from being priced.
      const individual = await Promise.allSettled(pairs.map(pair => safeJson(`https://data-api.binance.vision/api/v3/ticker/price?symbol=${pair}`)));
      for (const result of individual) if (result.status === 'fulfilled' && result.value?.symbol) binanceQuotes[result.value.symbol] = Number(result.value.price);
    }
  }

  let usdBrl = null;
  if (currency === 'brl' && assets.some(a => a.priceUsd != null || BINANCE_SYMBOLS[String(a.symbol||'').toUpperCase()] || ['USDT','USDC'].includes(String(a.symbol||'').toUpperCase()))) {
    try {
      const fx = await safeJson('https://api.frankfurter.app/latest?from=USD&to=BRL');
      usdBrl = Number(fx.rates?.BRL) || null;
    } catch { /* do not invent an FX rate */ }
  }
  return assets.map(asset => {
    const symbol = String(asset.symbol || '').toUpperCase();
    const cg = coinGeckoId(symbol);
    const quote = cg ? quotes[cg] : null;
    const binanceUsd = binanceQuotes[BINANCE_SYMBOLS[symbol]] ?? null;
    let priceUsd = quote?.usd ?? (binanceUsd != null ? binanceUsd : asset.priceUsd);
    if (['USDT','USDC'].includes(symbol) && priceUsd == null) priceUsd = 1;
    let price = currency === 'brl' ? (quote?.brl ?? (priceUsd != null && usdBrl ? priceUsd*usdBrl : null)) : (quote?.usd ?? priceUsd);
    return { ...asset, price, priceCurrency:currency, value:price==null?null:price*asset.amount, change24h:quote?.change24h??null, priceSource:quote?'CoinGecko':binanceUsd!=null?'Binance public market':asset.priceUsd!=null?'Blockscout':'unavailable' };
  });
}

export async function historicalPrice(symbol, timestamp, currency = 'brl', apiKey = '') {
  const id = coinGeckoId(symbol);
  if (!id || !timestamp) return null;
  try {
    const date = new Date(timestamp).toISOString().slice(0,10).split('-').reverse().join('-');
    const response = await fetch(`https://api.coingecko.com/api/v3/coins/${id}/history?date=${date}&localization=false`, { headers: apiKey ? { 'x-cg-demo-api-key': apiKey } : {} });
    if (!response.ok) return null;
    const json = await response.json();
    return json.market_data?.current_price?.[currency] ?? null;
  } catch { return null; }
}
