export function money(value, currency = 'BRL', compact = false) {
  if (value == null || !Number.isFinite(Number(value))) return '—';
  return new Intl.NumberFormat('pt-BR', { style:'currency', currency:currency.toUpperCase(), notation:compact?'compact':'standard', maximumFractionDigits: compact ? 2 : 2 }).format(value);
}
export function quantity(value) {
  return new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 8 }).format(Number(value || 0));
}
export function shortAddress(address, start = 7, end = 5) { return address?.length > start + end + 3 ? `${address.slice(0,start)}…${address.slice(-end)}` : address || '—'; }
export function dateTime(timestamp) {
  if (!timestamp) return 'Horário indisponível';
  return new Intl.DateTimeFormat('pt-BR', { dateStyle:'short', timeStyle:'short' }).format(new Date(timestamp));
}
export function totalValue(assets) { return assets.reduce((sum,a)=>sum+(a.value ?? 0),0); }
export function healthScore(assets) {
  const valued = assets.filter(a => a.value != null && a.value > 0);
  if (!valued.length) return null;
  const total = totalValue(valued);
  const hhi = valued.reduce((sum,a)=>sum+((a.value/total)**2),0);
  const diversification = Math.max(0, Math.min(100, Math.round((1-hhi)*125)));
  return { score: diversification, hhi, count: valued.length };
}
export function valueAt(snapshot, currency) { return Number(snapshot?.values?.[currency] ?? snapshot?.value ?? 0); }
export function periodChange(snapshots, currentValue, period, currency) {
  if (!snapshots?.length) return null;
  const now = Date.now();
  const ranges = { '1H':3600000, '24H':86400000, '7D':604800000, '1M':2592000000, '1A':31536000000, 'ALL':Infinity };
  const start = period === 'ALL' ? snapshots[0]?.timestamp : now - ranges[period];
  const candidates = snapshots.filter(s => s.timestamp <= start && s.timestamp > 0).sort((a,b)=>b.timestamp-a.timestamp);
  const baseline = candidates[0];
  if (!baseline || !currentValue || !valueAt(baseline,currency)) return null;
  const previous = valueAt(baseline,currency);
  return { amount: currentValue-previous, percent: ((currentValue-previous)/previous)*100, previous, timestamp:baseline.timestamp };
}
export function acquisitionTotals(trades, currency = 'brl') {
  const buys = trades.filter(t => t.type === 'buy' && (t.currency || 'brl') === currency);
  const costWithoutFees = buys.reduce((s,t)=>s+Number(t.quantity||0)*Number(t.unitPrice||0),0);
  const fees = buys.reduce((s,t)=>s+Number(t.networkFee||0),0);
  return { costWithoutFees, fees, costWithFees: costWithoutFees + fees, count: buys.length };
}
export function feeValue(feeTxs, currentPrices) {
  const lookup = new Map(currentPrices.map(a=>[a.symbol,a.price]));
  return feeTxs.reduce((sum,tx)=>sum+(Number(tx.fee||0)*Number(lookup.get(tx.feeAsset)||0)),0);
}
export function aggregateAssets(results, defiPositions = [], includeDefi = false) {
  const map = new Map();
  for (const result of results) {
    for (const asset of (result.assets || [])) {
      const key = `${asset.network || 'unknown'}:${asset.contract || asset.symbol}`;
      const old = map.get(key);
      if (old) { old.amount += asset.amount; if (old.price == null) old.price=asset.price; old.value = old.price == null ? null : old.amount * old.price; old.wallets++; }
      else map.set(key,{ ...asset, key, price:asset.price ?? null, value:asset.value ?? null, wallets:1 });
    }
  }
  if (includeDefi) for (const p of defiPositions.filter(p=>p.active !== false)) {
    const key = `DEFI:${p.id}`;
    map.set(key,{ key, symbol:p.symbol, name:p.name || p.symbol, amount:Number(p.amount||0), price:Number(p.price||0), value:Number(p.amount||0)*Number(p.price||0), network:p.network || 'DeFi', source:'manual' });
  }
  return [...map.values()].map(a=>({ ...a, value:a.price == null ? a.value : a.price*a.amount })).sort((a,b)=>(b.value||0)-(a.value||0));
}
