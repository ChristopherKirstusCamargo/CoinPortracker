import * as DB from './db.js';
import { NETWORKS, fetchWallet, validateAddress } from './providers.js';
import { fetchMarketPrices } from './market.js';
import { money, quantity, shortAddress, dateTime, totalValue, healthScore, periodChange, acquisitionTotals, feeValue, aggregateAssets } from './analytics.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = {
  wallets: [], results: [], transactions: [], trades: [], defi: [], snapshots: [],
  settings: { currency: 'brl', coinGeckoKey: '', includeDefi: false },
  assets: [], pricedAssets: [], currency: 'brl', period: '7D', view: 'dashboard',
  refreshing: false, noticesDismissed: false, storagePersisted: false
};
const COLORS = ['#927cff','#47d9c5','#f2bd70','#65a6ff','#e779a9','#8dd27d','#bd91ff','#ea8c69'];
const currencyCode = () => state.currency.toUpperCase();
const safe = (value) => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const id = () => crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

function toast(message, kind = 'success') {
  const region = $('#toast-region');
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.textContent = message;
  region.append(node);
  setTimeout(() => node.remove(), 4500);
}
function setSync(text, ok = true) {
  $('#sync-status').innerHTML = `<i style="background:${ok ? 'var(--cyan)' : 'var(--amber)'}"></i> ${safe(text)}`;
}
function setBusy(busy) {
  state.refreshing = busy;
  const button = $('#refresh-button');
  button.style.opacity = busy ? '.55' : '1';
  button.style.pointerEvents = busy ? 'none' : '';
  button.style.transform = busy ? 'rotate(180deg)' : '';
}
function sumCurrentValue() {
  return state.assets.reduce((sum, asset) => sum + (asset.value ?? 0), 0);
}
function allAssetsValued() { return state.assets.length > 0 && state.assets.every(asset => asset.value != null); }
function currentPrices() { return state.assets; }
function indexedTransactions() { return state.transactions.filter(tx => tx.feeAsset && tx.fee > 0); }

async function loadState() {
  state.wallets = await DB.all('wallets');
  state.trades = await DB.all('trades');
  state.defi = await DB.all('defi');
  state.snapshots = (await DB.all('snapshots')).sort((a,b)=>a.timestamp-b.timestamp);
  state.settings = { currency:'brl', coinGeckoKey:'', includeDefi:false };
  const settings = await DB.get('settings', 'main');
  if (settings?.value) state.settings = { ...state.settings, ...settings.value };
  state.currency = state.settings.currency || 'brl';
  state.results = await Promise.all(state.wallets.map(async wallet => await DB.get('cache', wallet.id)).filter(Boolean));
  state.results = state.results.filter(Boolean);
  await assemblePortfolio(false);
}

async function assemblePortfolio(saveSnapshot = false) {
  const flat = state.results.flatMap(result => result.assets || []);
  if (flat.length) {
    try {
      const priced = await fetchMarketPrices(flat, state.currency, state.settings.coinGeckoKey || '');
      let index = 0;
      state.results = state.results.map(result => ({ ...result, assets: result.assets.map(() => priced[index++]) }));
      for (const result of state.results) await DB.put('cache', result);
    } catch (error) {
      state.results = state.results.map(result => ({ ...result, assets: result.assets.map(asset => {
        const cachedPrice = asset.priceCurrency === state.currency ? asset.price : null;
        const price = cachedPrice ?? (state.currency === 'usd' ? asset.priceUsd : null);
        return { ...asset, price, value:price == null ? null : asset.amount*price, stalePrice:cachedPrice != null };
      }) }));
      for (const result of state.results) await DB.put('cache', result);
      setSync('Preço em cache / indisponível', false);
      if (saveSnapshot) toast(error.message, 'error');
    }
  }
  state.transactions = [...new Map(state.results.flatMap(result => result.transactions || []).map(tx => [tx.id, tx])).values()].sort((a,b)=>(b.timestamp||0)-(a.timestamp||0));
  const baseAssets = aggregateAssets(state.results);
  state.assets = baseAssets.map(asset => ({ ...asset, value: asset.price == null ? asset.value : asset.amount * asset.price }));
  if (state.settings.includeDefi) {
    const defiPositions = state.defi.filter(item => item.kind === 'position' && (item.currency || 'brl') === state.currency);
    state.assets = aggregateAssets(state.results, defiPositions, true).map(asset => ({ ...asset, value: asset.price == null ? asset.value : asset.amount * asset.price }));
  }
  if (saveSnapshot && state.wallets.length && allAssetsValued()) {
    const value = sumCurrentValue();
    const snapshot = { id: String(Date.now()), timestamp: Date.now(), value, currency: state.currency, includeDefi: Boolean(state.settings.includeDefi), values: { [state.currency]: value }, wallets: state.wallets.length, assets: state.assets.length };
    await DB.put('snapshots', snapshot);
    state.snapshots.push(snapshot);
    state.snapshots.sort((a,b)=>a.timestamp-b.timestamp);
  }
}

async function refreshAll(showMessage = true) {
  if (state.refreshing) return;
  if (!state.wallets.length) { toast('Adicione uma carteira pública para consultar os saldos.', 'error'); return; }
  setBusy(true); setSync('Consultando redes…');
  const results = [];
  const failures = [];
  for (const wallet of state.wallets) {
    try {
      const result = await fetchWallet(wallet);
      await DB.put('cache', result);
      results.push(result);
    } catch (error) {
      failures.push(`${wallet.label || NETWORKS[wallet.network]?.name || wallet.network}: ${error.message}`);
      const cached = await DB.get('cache', wallet.id);
      if (cached) results.push({ ...cached, stale: true, error: error.message });
      else results.push({ walletId: wallet.id, network: wallet.network, status: 'error', assets: [], transactions: [], error: error.message, fees: 0 });
    }
  }
  state.results = results;
  await assemblePortfolio(true);
  setBusy(false);
  setSync(failures.length ? `${failures.length} rede(s) com erro` : 'Dados atualizados', failures.length === 0);
  renderCurrentView();
  if (showMessage) {
    if (failures.length) toast(`Consulta parcial. ${failures.join(' | ')}`, 'error');
    else toast('Carteiras atualizadas. Novo snapshot salvo localmente.');
  }
}

function renderDashboard() {
  const dateNode=$('#dashboard-date');
  if(dateNode) dateNode.textContent=new Intl.DateTimeFormat('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(new Date()).toUpperCase();
  const value = sumCurrentValue();
  const valuedCount = state.assets.filter(a=>a.value != null).length;
  $('#total-value').textContent = state.assets.length ? (valuedCount ? money(value,currencyCode()) : 'Preço indisponível') : money(0,currencyCode());
  $('#asset-count').textContent = `${state.assets.length} ativos monitorados${valuedCount < state.assets.length ? ` · ${state.assets.length-valuedCount} sem preço` : ''}`;
  const costs = acquisitionTotals(state.trades, state.currency);
  const pnl = value - costs.costWithFees;
  if (costs.count && allAssetsValued()) {
    $('#total-pnl').textContent = money(pnl,currencyCode());
    $('#total-pnl').style.color = pnl >= 0 ? 'var(--green)' : 'var(--red)';
    $('#pnl-percent').textContent = `${costs.costWithFees > 0 ? (pnl/costs.costWithFees*100).toFixed(2).replace('.',',') : '0,00'}%`;
    $('#pnl-percent').className = `metric-tag ${pnl>=0?'positive':'negative'}`;
    $('#cost-basis-label').textContent = `Base manual: ${money(costs.costWithFees,currencyCode())}`;
  } else {
    $('#total-pnl').textContent = '—';
    $('#total-pnl').style.color = '';
    $('#pnl-percent').textContent = 'Sem base';
    $('#pnl-percent').className = 'metric-tag neutral';
    $('#cost-basis-label').textContent = costs.count ? 'Aguardando preços atuais' : 'Cadastre seus custos para calcular';
  }
  const fees = feeValue(indexedTransactions(), currentPrices());
  $('#total-fees').textContent = indexedTransactions().length ? money(fees,currencyCode()) : '—';
  $('#fee-count').textContent = `${indexedTransactions().length} eventos`;
  const health = healthScore(state.assets);
  $('#health-score').textContent = health ? `${health.score}` : '—';
  $('#health-meter-fill').style.width = `${health?.score || 0}%`;
  $('#health-caption').textContent = health ? (health.score >= 70 ? 'Boa dispersão relativa' : health.score >= 35 ? 'Concentração moderada' : 'Alta concentração') : 'Aguardando ativos';
  $('#tx-count').textContent = state.transactions.length;
  $('#currency-label').textContent = currencyCode();
  const periods=[['1h','1H'],['24h','24H'],['7d','7D'],['1y','1A']];
  const comparableSnapshots=state.snapshots.filter(s=>s.currency===state.currency&&(s.includeDefi??false)===Boolean(state.settings.includeDefi));
  for(const [key,period] of periods){
    const change=periodChange(comparableSnapshots,value,period,state.currency);
    const valueNode=$(`#period-pnl-${key}`),labelNode=$(`#period-label-${key}`);
    if(valueNode&&labelNode){valueNode.textContent=change?`${change.amount>=0?'+':''}${money(change.amount,currencyCode())}`:'—';valueNode.style.color=change?(change.amount>=0?'var(--green)':'var(--red)'):'';labelNode.textContent=change?`${change.percent>=0?'+':''}${change.percent.toFixed(2).replace('.',',')}% · variação entre snapshots`:'São necessários snapshots neste período';}
  }
  renderHoldings(); renderWallets(); renderAllocation(); renderChart();
  $('#provider-notice').style.display = state.noticesDismissed || state.wallets.length ? 'none' : 'flex';
}

function renderHoldings() {
  const body = $('#holdings-body');
  if (!state.assets.length) {
    body.innerHTML = `<tr><td colspan="5"><div class="empty-state"><div class="empty-icon">◈</div><strong>Nenhuma carteira conectada</strong><span>Adicione um endereço público para começar a acompanhar seus ativos.</span><button class="button button-primary button-small" id="empty-add-wallet">Adicionar carteira</button></div></td></tr>`;
    return;
  }
  const total = sumCurrentValue();
  body.innerHTML = state.assets.map(asset => {
    const allocation = total > 0 && asset.value != null ? asset.value / total * 100 : 0;
    return `<tr><td><div class="asset-cell"><div class="asset-logo">${safe(asset.symbol.slice(0,3))}</div><div class="asset-name"><strong>${safe(asset.name || asset.symbol)}</strong><span>${safe(asset.symbol)} · ${safe(asset.network || 'Rede desconhecida')}</span></div></div></td><td class="mono">${quantity(asset.amount)}</td><td class="mono">${asset.price == null ? '—' : money(asset.price,currencyCode())}</td><td class="mono">${asset.value == null ? '—' : money(asset.value,currencyCode())}</td><td><div class="allocation-cell"><div class="allocation-bar"><span style="width:${allocation}%"></span></div><span class="mono">${asset.value == null ? '—' : `${allocation.toFixed(1).replace('.',',')}%`}</span></div></td></tr>`;
  }).join('');
}

function renderWallets() {
  const container = $('#wallet-list');
  if (!state.wallets.length) { container.innerHTML = `<div class="wallet-empty"><span class="wallet-empty-icon">⌑</span><span>Nenhuma carteira adicionada.</span></div>`; return; }
  container.innerHTML = state.wallets.map(wallet => {
    const result = state.results.find(r=>r.walletId===wallet.id);
    const native = result?.assets?.[0];
    const oldestLabel=result?.oldestTimestamp?`Mais antiga indexada: ${dateTime(result.oldestTimestamp)}`:'Sem data histórica disponível';
    return `<div class="wallet-row"><div class="wallet-network-icon">${safe(NETWORKS[wallet.network]?.symbol || 'CR')}</div><div class="wallet-info"><strong>${safe(wallet.label || NETWORKS[wallet.network]?.name || wallet.network)}</strong><span>${safe(shortAddress(wallet.address))}</span><span>${safe(oldestLabel)}</span></div><div class="wallet-balance">${native ? quantity(native.amount)+' '+safe(native.symbol) : result?.error ? 'Erro' : '—'}</div><button class="wallet-remove" data-remove-wallet="${safe(wallet.id)}" title="Remover carteira" aria-label="Remover carteira">×</button></div>`;
  }).join('');
}

function renderAllocation() {
  const legend = $('#allocation-legend');
  const donut = $('#allocation-donut');
  const assets = state.assets.filter(a=>a.value != null && a.value > 0).slice(0,8);
  const total = assets.reduce((s,a)=>s+a.value,0);
  $('#allocation-assets').textContent = assets.length;
  if (!assets.length || !total) { donut.style.background = 'conic-gradient(#273141 0 100%)'; legend.innerHTML = '<div class="empty-inline">Nenhum ativo com preço disponível.</div>'; return; }
  let cursor = 0;
  const stops = assets.map((a,i)=>{ const start=cursor; cursor += a.value/total*100; return `${COLORS[i%COLORS.length]} ${start}% ${cursor}%`; });
  donut.style.background = `conic-gradient(${stops.join(',')})`;
  legend.innerHTML = assets.slice(0,6).map((a,i)=>`<div class="legend-row"><span class="legend-dot" style="background:${COLORS[i%COLORS.length]}"></span><span class="legend-name">${safe(a.symbol)}</span><span class="legend-value">${(a.value/total*100).toFixed(1).replace('.',',')}%</span></div>`).join('');
}

function renderChart() {
  const canvas = $('#performance-chart');
  const empty = $('#chart-empty');
  const width = canvas.clientWidth || 600;
  const height = canvas.clientHeight || 190;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = width*dpr; canvas.height = height*dpr;
  const ctx = canvas.getContext('2d'); ctx.scale(dpr,dpr); ctx.clearRect(0,0,width,height);
  const now = Date.now();
  const periodMs = { '1H':3600000,'24H':86400000,'7D':604800000,'1M':2592000000,'1A':31536000000,'ALL':Infinity }[state.period];
  const cutoff = state.period === 'ALL' ? 0 : now-periodMs;
  const data = state.snapshots.filter(s=>s.currency===state.currency&&(s.includeDefi??false)===Boolean(state.settings.includeDefi) && s.timestamp>=cutoff).sort((a,b)=>a.timestamp-b.timestamp);
  const current = sumCurrentValue();
  $('#chart-current-value').textContent = state.assets.length ? money(current,currencyCode()) : money(0,currencyCode());
  const change = periodChange(state.snapshots.filter(s=>s.currency===state.currency&&(s.includeDefi??false)===Boolean(state.settings.includeDefi)), current, state.period, state.currency);
  $('#chart-period-change').textContent = change ? `${change.amount>=0?'+':''}${money(change.amount,currencyCode())} (${change.percent>=0?'+':''}${change.percent.toFixed(2).replace('.',',')}%) · variação entre snapshots` : 'Sem histórico suficiente para este período';
  $('#chart-period-change').style.color = change ? (change.amount>=0?'var(--green)':'var(--red)') : 'var(--muted-2)';
  empty.classList.toggle('visible', data.length < 2);
  if (data.length < 2) { $('#chart-start-label').textContent = state.snapshots.length ? 'Primeiro snapshot' : 'Aguardando histórico'; $('#chart-end-label').textContent = state.snapshots.length ? 'Mais recente' : 'Agora'; return; }
  const values = data.map(s=>Number(s.values?.[state.currency] ?? s.value ?? 0));
  const min = Math.min(...values), max = Math.max(...values), range = max-min || Math.max(max*.04,1);
  const pad = { l:8,r:8,t:12,b:15};
  const point = (index,value)=>({ x:pad.l+index*(width-pad.l-pad.r)/(data.length-1), y:pad.t+(max-value)/range*(height-pad.t-pad.b) });
  const points = values.map((v,i)=>point(i,v));
  ctx.strokeStyle = '#273447'; ctx.lineWidth=1; ctx.setLineDash([3,5]);
  for(let i=0;i<4;i++){const y=pad.t+i*(height-pad.t-pad.b)/3;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(width-pad.r,y);ctx.stroke();}
  ctx.setLineDash([]);
  const gradient=ctx.createLinearGradient(0,pad.t,0,height);gradient.addColorStop(0,'rgba(146,124,255,.28)');gradient.addColorStop(1,'rgba(146,124,255,0)');
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.lineTo(points.at(-1).x,height-pad.b);ctx.lineTo(points[0].x,height-pad.b);ctx.closePath();ctx.fillStyle=gradient;ctx.fill();
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.lineWidth=2;ctx.strokeStyle='#9a87ff';ctx.lineJoin='round';ctx.lineCap='round';ctx.shadowColor='rgba(146,124,255,.28)';ctx.shadowBlur=10;ctx.stroke();ctx.shadowBlur=0;
  const last=points.at(-1);ctx.beginPath();ctx.arc(last.x,last.y,3.2,0,Math.PI*2);ctx.fillStyle='#47d9c5';ctx.fill();ctx.strokeStyle='#0f1722';ctx.lineWidth=2;ctx.stroke();
  $('#chart-start-label').textContent = new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short'}).format(new Date(data[0].timestamp));
  $('#chart-end-label').textContent = new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short'}).format(new Date(data.at(-1).timestamp));
}

function renderTransactions() {
  const txs = state.transactions;
  const totalFees = feeValue(indexedTransactions(),currentPrices());
  const root = $('#app-view');
  root.innerHTML = `<section class="page-heading"><div><p class="eyebrow">RASTREABILIDADE ON-CHAIN</p><h1>Transações</h1><p class="subheading">Eventos públicos encontrados nos endereços conectados.</p></div><div class="heading-actions"><button class="button button-quiet" data-view="dashboard">← Visão geral</button><button class="button button-primary" id="refresh-view">↻ Atualizar dados</button></div></section>
    <div class="stat-strip"><div class="stat-mini"><span>Eventos indexados</span><strong>${txs.length}</strong></div><div class="stat-mini"><span>Carteiras consultadas</span><strong>${state.wallets.length}</strong></div><div class="stat-mini"><span>Taxas on-chain estimadas*</span><strong>${money(totalFees,currencyCode())}</strong></div></div>
    <section class="panel"><div class="panel-heading"><div><h2>Histórico público</h2><p>Busca por hash, endereço, ativo, rede, data ou quantidade.</p></div><span class="pill-muted">${txs.length} registros carregados</span></div>
      <div class="toolbar"><input class="search-input" id="tx-search" placeholder="Pesquisar endereço, hash, ativo ou valor…" /><select class="filter-select" id="tx-network"><option value="">Todas as redes</option>${Object.entries(NETWORKS).map(([k,n])=>`<option value="${k}">${safe(n.name)}</option>`).join('')}</select><select class="filter-select" id="tx-type"><option value="">Todos os tipos</option><option value="in">Entrada</option><option value="out">Saída</option><option value="self">Interna / sem delta</option></select><input class="filter-select" id="tx-date" type="date" aria-label="Filtrar pela data" /></div>
      <div class="table-scroll"><table class="view-table"><thead><tr><th>Data / Hora</th><th>Rede / Ativo</th><th>Tipo</th><th>Quantidade</th><th>Taxa</th><th>Origem / Destino</th><th>Transação</th></tr></thead><tbody id="tx-body">${transactionRows(txs)}</tbody></table></div>
    </section><p class="page-footer">*Taxas exibidas são as encontradas no conjunto de transações carregado. A indexação atual é limitada por rede e não deve ser interpretada como auditoria histórica completa. Clique no identificador para abrir o explorer.</p>`;
  $('#tx-search').addEventListener('input', filterTransactions);
  $('#tx-network').addEventListener('change', filterTransactions);
  $('#tx-type').addEventListener('change', filterTransactions);
  $('#tx-date').addEventListener('change', filterTransactions);
}
function transactionRows(txs) {
  if (!txs.length) return '<tr><td class="empty-row" colspan="7">Nenhuma transação encontrada. Adicione uma carteira ou atualize os dados.</td></tr>';
  return txs.map(tx=>{
    const network=NETWORKS[tx.network];
    const explorer=network?.explorer ? `${network.explorer}${tx.network==='bitcoin'?tx.from||'':tx.walletId?state.wallets.find(w=>w.id===tx.walletId)?.address||'':''}` : '#';
    const txUrl=tx.network==='bitcoin'?`https://mempool.space/tx/${tx.txid}`:tx.network==='solana'?`https://explorer.solana.com/tx/${tx.txid}`:`${network?.host || ''}/tx/${tx.txid}`;
    const typ=tx.type==='in'?'Entrada':tx.type==='out'?'Saída':'Interna';
    return `<tr><td>${dateTime(tx.timestamp)}</td><td><strong>${safe(network?.name||tx.network)}</strong><br><span class="muted">${safe(tx.asset||'—')}</span></td><td><span class="type-pill ${tx.type}">${typ}</span></td><td class="mono">${quantity(tx.amount)} ${safe(tx.asset||'')}</td><td class="mono">${tx.fee ? `${quantity(tx.fee)} ${safe(tx.feeAsset||'')}` : '—'}</td><td><span class="mono">${safe(shortAddress(tx.from||'—',5,4))} → ${safe(shortAddress(tx.to||'—',5,4))}</span></td><td><a href="${safe(txUrl)}" target="_blank" rel="noopener noreferrer" class="small-link">${safe(shortAddress(tx.txid,7,5))} ↗</a></td></tr>`;
  }).join('');
}
function filterTransactions() {
  const query=$('#tx-search').value.trim().toLowerCase(), network=$('#tx-network').value, type=$('#tx-type').value, date=$('#tx-date').value;
  const filtered=state.transactions.filter(tx=>{
    const hay=[tx.txid,tx.from,tx.to,tx.asset,tx.network,tx.amount,tx.fee].join(' ').toLowerCase();
    const localDate=tx.timestamp?`${new Date(tx.timestamp).getFullYear()}-${String(new Date(tx.timestamp).getMonth()+1).padStart(2,'0')}-${String(new Date(tx.timestamp).getDate()).padStart(2,'0')}`:'';
    return (!query||hay.includes(query))&&(!network||tx.network===network)&&(!type||tx.type===type)&&(!date||localDate===date);
  });
  $('#tx-body').innerHTML=transactionRows(filtered);
}

function renderCosts() {
  const totals=acquisitionTotals(state.trades,state.currency);
  const fees=feeValue(indexedTransactions(),currentPrices());
  $('#app-view').innerHTML=`<section class="page-heading"><div><p class="eyebrow">CUSTO DE AQUISIÇÃO E GAS</p><h1>Custos e taxas</h1><p class="subheading">Separe o preço pago pelo ativo das taxas de execução da rede.</p></div><div class="heading-actions"><button class="button button-primary" id="open-buy-form">＋ Registrar aquisição</button></div></section>
    <div class="stat-strip"><div class="stat-mini"><span>Custo de aquisição sem taxa</span><strong>${money(totals.costWithoutFees,currencyCode())}</strong></div><div class="stat-mini"><span>Custo de aquisição com taxas informadas</span><strong>${money(totals.costWithFees,currencyCode())}</strong></div><div class="stat-mini"><span>Taxas on-chain indexadas*</span><strong>${money(fees,currencyCode())}</strong></div></div>
    <section class="panel" id="buy-form-panel" style="display:none"><div class="panel-heading"><div><h2>Novo registro de aquisição</h2><p>Informe os valores na moeda-base selecionada (${currencyCode()}).</p></div><button class="small-link" id="close-buy-form">Fechar ×</button></div><form id="buy-form"><div class="form-grid"><div class="field"><label>Ativo</label><input name="asset" placeholder="BTC, ETH, SOL…" required maxlength="12" /></div><div class="field"><label>Quantidade adquirida</label><input name="quantity" type="number" min="0" step="any" placeholder="0,00" required /></div><div class="field"><label>Preço unitário (${currencyCode()})</label><input name="unitPrice" type="number" min="0" step="any" placeholder="0,00" required /></div><div class="field"><label>Taxa de rede paga (${currencyCode()})</label><input name="networkFee" type="number" min="0" step="any" value="0" /></div><div class="field"><label>Data da aquisição</label><input name="date" type="datetime-local" required value="${new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16)}" /></div><div class="field"><label>Origem / observação</label><input name="note" placeholder="Exchange, swap, transferência…" maxlength="90" /></div></div><div class="form-actions"><button class="button button-quiet" type="button" id="close-buy-form-2">Cancelar</button><button class="button button-primary" type="submit">Salvar custo</button></div></form></section>
    <section class="panel"><div class="panel-heading"><div><h2>Registros de aquisição</h2><p>Base manual para custo médio e P/L estimado.</p></div><span class="pill-muted">${totals.count} compras</span></div><div class="table-scroll"><table class="view-table"><thead><tr><th>Data</th><th>Ativo</th><th>Quantidade</th><th>Preço unitário</th><th>Taxa informada</th><th>Custo total</th><th>Origem</th><th></th></tr></thead><tbody>${state.trades.filter(t=>t.type==='buy').sort((a,b)=>b.timestamp-a.timestamp).map(t=>`<tr><td>${dateTime(t.timestamp)}</td><td><strong>${safe(t.asset)}</strong></td><td class="mono">${quantity(t.quantity)}</td><td class="mono">${money(t.unitPrice,(t.currency||'brl').toUpperCase())}</td><td class="mono">${money(t.networkFee||0,(t.currency||'brl').toUpperCase())}</td><td class="mono">${money(t.quantity*t.unitPrice+(t.networkFee||0),(t.currency||'brl').toUpperCase())}</td><td>${safe(t.note||'Manual')}</td><td><button class="wallet-remove" data-delete-trade="${safe(t.id)}" aria-label="Excluir registro">×</button></td></tr>`).join('')||'<tr><td class="empty-row" colspan="8">Nenhum custo registrado. Adicione uma aquisição ou importe seus registros.</td></tr>'}</tbody></table></div></section>
    <div class="info-panel"><strong>Interpretação dos números:</strong> os custos manuais são separados das taxas observadas on-chain. A soma das taxas indexadas não equivale necessariamente a todas as taxas pagas desde a criação da carteira: o número de eventos depende do histórico que cada provedor disponibilizou. Transferências recebidas não são classificadas automaticamente como compras.</div>
    <p class="page-footer">Os lançamentos de aquisição são armazenados na moeda selecionada quando foram criados; só os registros na moeda-base atual entram nesta soma. O P/L calculado nesta versão é uma estimativa simples (valor atual menos compras registradas). Vendas, swaps, transferências próprias, airdrops e custo fiscal por lote ainda precisam de classificação/importação para um resultado contábil completo.</p>`;
}

function renderDefi() {
  const positions=state.defi.filter(x=>x.kind==='position');
  const rewards=state.defi.filter(x=>x.kind==='reward').sort((a,b)=>b.timestamp-a.timestamp);
  const total=positions.filter(p=>(p.currency||'brl')===state.currency).reduce((s,p)=>s+Number(p.amount||0)*Number(p.price||0),0);
  const rewardValue=rewards.filter(r=>(r.currency||'brl')===state.currency).reduce((s,r)=>s+Number(r.amount||0)*Number(r.unitPrice||0),0);
  $('#app-view').innerHTML=`<section class="page-heading"><div><p class="eyebrow">STAKING · LENDING · LIQUIDITY</p><h1>DeFi</h1><p class="subheading">Posições e recompensas descentralizadas, integradas ao portfólio.</p></div><div class="heading-actions"><button class="button button-primary" id="open-defi-form">＋ Adicionar posição</button></div></section>
    <div class="stat-strip"><div class="stat-mini"><span>Valor das posições DeFi</span><strong>${money(total,currencyCode())}</strong></div><div class="stat-mini"><span>Recompensas registradas</span><strong>${money(rewardValue,currencyCode())}</strong></div><div class="stat-mini"><span>Eventos de recompensa</span><strong>${rewards.length}</strong></div></div>
    <div class="info-panel"><strong>Nota sobre cobertura automática:</strong> DeFi não é um padrão único. Pools, staking líquido, lending e rewards usam contratos e eventos diferentes. Esta versão permite registrar posições e recompensas manualmente com bloco/slot e horário; ela não afirma detectar automaticamente todos os protocolos da carteira. Os adaptadores por protocolo devem ser adicionados separadamente.</div>
    <section class="panel" id="defi-form-panel" style="display:none"><div class="panel-heading"><div><h2>Adicionar posição ou recompensa</h2><p>O registro é salvo somente no navegador.</p></div><button class="small-link" id="close-defi-form">Fechar ×</button></div><form id="defi-form"><div class="form-grid"><div class="field"><label>Tipo de registro</label><select name="kind"><option value="position">Posição DeFi</option><option value="reward">Recompensa recebida</option></select></div><div class="field"><label>Protocolo / pool</label><input name="protocol" placeholder="Ex.: Marinade, Jito, Uniswap…" required /></div><div class="field"><label>Rede</label><select name="network"><option>Solana</option><option>Ethereum</option><option>Base</option><option>Arbitrum</option><option>Optimism</option><option>Polygon</option><option>Bitcoin</option></select></div><div class="field"><label>Ativo / símbolo</label><input name="symbol" placeholder="SOL, mSOL, ETH…" required maxlength="14" /></div><div class="field"><label>Quantidade</label><input name="amount" type="number" min="0" step="any" required /></div><div class="field"><label>Preço unitário (${currencyCode()})</label><input name="unitPrice" type="number" min="0" step="any" value="0" /></div><div class="field"><label>Bloco / slot de origem</label><input name="block" placeholder="Número do bloco ou slot" /></div><div class="field"><label>Data e hora do evento</label><input name="date" type="datetime-local" required value="${new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16)}" /></div><div class="field" style="grid-column:1/-1"><label>TxID / observação</label><input name="txid" placeholder="Hash da transação (opcional)" /></div></div><div class="form-actions"><button type="button" class="button button-quiet" id="close-defi-form-2">Cancelar</button><button type="submit" class="button button-primary">Salvar registro</button></div></form></section>
    <section class="content-grid"><article class="panel"><div class="panel-heading"><div><h2>Posições DeFi</h2><p>Saldo informado pelo usuário</p></div><span class="pill-muted">${positions.length} posições</span></div><div>${positions.map(p=>`<div class="defi-position"><div><strong>${safe(p.protocol)} · ${safe(p.symbol)}</strong><span>${safe(p.network)} · ${quantity(p.amount)} ${safe(p.symbol)}</span></div><div style="text-align:right"><strong>${money(p.amount*p.price,(p.currency||'brl').toUpperCase())}</strong><button class="small-link" data-delete-defi="${safe(p.id)}">Remover</button></div></div>`).join('')||'<div class="empty-row">Nenhuma posição cadastrada.</div>'}</div></article><article class="panel"><div class="panel-heading"><div><h2>Integração ao saldo</h2><p>Controle a composição do portfólio.</p></div></div><div class="setting-row"><div><strong>Incluir DeFi no valor total</strong><span>Adiciona as posições registradas ao dashboard e à alocação.</span></div><button class="toggle ${state.settings.includeDefi?'on':''}" id="toggle-defi" role="switch" aria-checked="${state.settings.includeDefi}" aria-label="Incluir DeFi no saldo total"></button></div><div class="info-panel" style="margin-top:13px">${state.settings.includeDefi?'DeFi está incluído no valor consolidado.':'DeFi está separado do saldo principal.'}</div></article></section>
    <section class="panel"><div class="panel-heading"><div><h2>Recompensas DeFi</h2><p>Data, horário, bloco/slot e quantidade recebida.</p></div><span class="pill-muted">${rewards.length} eventos</span></div><div class="table-scroll"><table class="view-table"><thead><tr><th>Data / Hora</th><th>Protocolo</th><th>Ativo</th><th>Quantidade</th><th>Valor registrado</th><th>Bloco / Slot</th><th>TxID</th><th></th></tr></thead><tbody>${rewards.map(r=>`<tr><td>${dateTime(r.timestamp)}</td><td>${safe(r.protocol)}</td><td>${safe(r.symbol)}</td><td class="mono">${quantity(r.amount)}</td><td class="mono">${money(r.amount*r.unitPrice,(r.currency||'brl').toUpperCase())}</td><td class="mono">${safe(r.block||'—')}</td><td class="mono">${safe(shortAddress(r.txid||'—'))}</td><td><button class="wallet-remove" data-delete-defi="${safe(r.id)}">×</button></td></tr>`).join('')||'<tr><td class="empty-row" colspan="8">Nenhuma recompensa cadastrada.</td></tr>'}</tbody></table></div></section>`;
}

function renderSettings() {
  $('#app-view').innerHTML=`<section class="page-heading"><div><p class="eyebrow">CONTROLE LOCAL E PREFERÊNCIAS</p><h1>Configurações</h1><p class="subheading">Defina como o CoinPortracker consulta e consolida seus dados.</p></div></section>
    <div class="settings-grid"><section class="settings-card"><h3>Moeda e mercado</h3><p>O preço de mercado é consultado diretamente no provedor. A chave Demo é opcional neste protótipo e fica armazenada no IndexedDB local.</p><div class="field"><label>Moeda-base</label><select id="settings-currency" class="settings-input"><option value="brl" ${state.currency==='brl'?'selected':''}>Real brasileiro (BRL)</option><option value="usd" ${state.currency==='usd'?'selected':''}>Dólar americano (USD)</option></select></div><div class="field" style="margin-top:14px"><label>CoinGecko Demo API Key (opcional)</label><input id="coingecko-key" class="settings-input" type="password" autocomplete="off" placeholder="Cole sua chave Demo" value="${safe(state.settings.coinGeckoKey||'')}" /></div><div class="form-actions"><button class="button button-primary" id="save-settings">Salvar preferências</button></div></section>
    <section class="settings-card"><h3>Integração de carteira</h3><p>Ative ou desative componentes da composição financeira.</p><div class="setting-row"><div><strong>Incluir posições DeFi no saldo total</strong><span>Considera posições cadastradas manualmente.</span></div><button class="toggle ${state.settings.includeDefi?'on':''}" id="toggle-defi-settings" role="switch" aria-checked="${state.settings.includeDefi}" aria-label="Incluir DeFi"></button></div><div class="setting-row"><div><strong>Atualização manual</strong><span>Sem polling em segundo plano. Você decide quando consultar.</span></div><span class="pill-muted">Sob demanda</span></div></section>
    <section class="settings-card"><h3>Privacidade e armazenamento</h3><p>O aplicativo não possui login, backend próprio, pixels de anúncio ou ferramenta de analytics.</p><div class="setting-row"><div><strong>IndexedDB local</strong><span>Endereços, cache, snapshots e lançamentos ficam neste navegador.</span></div><span class="pill-muted">Ativo</span></div><div class="setting-row"><div><strong>Persistência solicitada</strong><span>O navegador pode proteger o armazenamento contra limpeza automática.</span></div><span class="pill-muted">${state.storagePersisted ? 'Concedido' : 'Não confirmado'}</span></div><div class="setting-row"><div><strong>Backup e restauração</strong><span>Exporte ou importe todo o seu conjunto de dados em JSON.</span></div><div style="display:flex;gap:6px"><button class="button button-small" id="settings-export">Exportar</button><button class="button button-small" id="settings-import">Importar</button></div></div></section>
    <section class="settings-card danger"><h3>Zona de risco</h3><p>Estas ações são locais e podem ser irreversíveis sem um backup.</p><div class="setting-row"><div><strong>Apagar dados locais</strong><span>Remove carteiras, cache, custos, snapshots e registros DeFi deste navegador.</span></div><button class="button button-small" id="clear-local-data">Apagar dados</button></div></section></div>
    <div class="info-panel" style="margin-top:14px"><strong>Limite de privacidade:</strong> o aplicativo não envia dados a um servidor CoinPortracker, mas as APIs públicas consultadas recebem seu endereço público e o IP da conexão. GitHub Pages e Google Fonts também podem receber requisições técnicas de carregamento. Para privacidade máxima, use uma cópia local e hospede fontes/arquivos localmente. Nunca insira uma chave privada, seed phrase ou arquivo de carteira.</div>
    <div class="info-panel" style="margin-top:12px"><strong>Limite técnico:</strong> “período total” de uma carteira exige indexação integral de transações, preços históricos e tratamento de fluxos internos. A primeira transação encontrada é uma referência cronológica, não prova o início do investimento. O gráfico desta versão começa no primeiro snapshot local; P/L por período é variação entre snapshots e ainda não é ajustado por aportes/saques.</div>`;
}

function headingFor(view) { return ({dashboard:'Visão geral',transactions:'Transações',costs:'Custos e taxas',defi:'DeFi',settings:'Configurações'})[view] || 'CoinPortracker'; }
function renderCurrentView() {
  $('#page-name').textContent=headingFor(state.view);
  $$('.nav-item[data-view]').forEach(button=>button.classList.toggle('active',button.dataset.view===state.view));
  if(state.view==='dashboard') { $('#app-view').innerHTML=dashboardTemplate; renderDashboard(); }
  else if(state.view==='transactions') renderTransactions();
  else if(state.view==='costs') renderCosts();
  else if(state.view==='defi') renderDefi();
  else if(state.view==='settings') renderSettings();
}
const dashboardTemplate = $('#app-view').innerHTML;
function navigate(view) { state.view=view; renderCurrentView(); $('#sidebar').classList.remove('open'); window.scrollTo({top:0,behavior:'smooth'}); }

function openWalletModal() { $('#wallet-modal').classList.add('open'); $('#wallet-modal').setAttribute('aria-hidden','false'); $('#wallet-address').focus(); }
function closeWalletModal() { $('#wallet-modal').classList.remove('open'); $('#wallet-modal').setAttribute('aria-hidden','true'); }
function bindModal() { $$('[data-close-modal]').forEach(btn=>btn.addEventListener('click',closeWalletModal)); $('#wallet-modal').addEventListener('click',event=>{if(event.target===$('#wallet-modal'))closeWalletModal();}); }

$('#wallet-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const formElement=event.currentTarget;
  const form=new FormData(formElement);
  const wallet={id:id(),label:String(form.get('label')||'').trim(),network:String(form.get('network')),address:String(form.get('address')||'').trim(),createdAt:Date.now()};
  try {
    validateAddress(wallet);
    const normalizeAddress = value => ['ethereum','base','arbitrum','optimism','polygon'].includes(wallet.network) ? value.toLowerCase() : value;
    if(state.wallets.some(w=>w.network===wallet.network&&normalizeAddress(w.address)===normalizeAddress(wallet.address))) throw new Error('Este endereço já está cadastrado nesta rede.');
    const button=$('#add-wallet-submit');button.disabled=true;button.textContent='Conectando…';
    await DB.put('wallets',wallet);state.wallets.push(wallet);closeWalletModal();formElement.reset();
    await refreshAll(false);navigate('dashboard');
    const result=state.results.find(item=>item.walletId===wallet.id);
    if(result?.status==='error') toast(`Carteira salva, mas a consulta falhou: ${result.error}`,'error');
    else toast('Carteira adicionada. Os dados continuam somente no seu navegador.');
  } catch(error) { toast(error.message,'error'); }
  finally { const button=$('#add-wallet-submit');button.disabled=false;button.innerHTML='Conectar endereço <span>→</span>'; }
});

function exportBackup() {
  DB.exportDatabase().then(payload=>{
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`coinportracker-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);toast('Backup JSON exportado. Guarde-o em local seguro.');
  }).catch(error=>toast(error.message,'error'));
}
function importBackup() {
  const input=document.createElement('input');input.type='file';input.accept='application/json,.json';
  input.addEventListener('change',async()=>{
    const file=input.files?.[0];if(!file)return;
    try{const payload=JSON.parse(await file.text());await DB.importDatabase(payload);await loadState();renderCurrentView();toast('Backup importado. Dados locais atualizados.');}
    catch(error){toast(error.message||'Não foi possível importar o backup.','error');}
  });input.click();
}

// Global event delegation keeps the single-page navigation dependency-free.
document.addEventListener('click',async event=>{
  const viewButton=event.target.closest('[data-view]');if(viewButton){navigate(viewButton.dataset.view);return;}
  if(event.target.closest('#open-add-wallet')||event.target.closest('#open-add-wallet-secondary')||event.target.closest('#empty-add-wallet')){openWalletModal();return;}
  if(event.target.closest('#refresh-button')||event.target.closest('#refresh-view')){await refreshAll();return;}
  if(event.target.closest('#export-backup')||event.target.closest('#settings-export')){exportBackup();return;}
  if(event.target.closest('#settings-import')){importBackup();return;}
  const removeWallet=event.target.closest('[data-remove-wallet]');if(removeWallet){const wallet=state.wallets.find(w=>w.id===removeWallet.dataset.removeWallet);if(!wallet)return;if(confirm(`Remover a carteira ${wallet.label||shortAddress(wallet.address)}? Os eventos armazenados em cache também serão removidos.`)){await DB.remove('wallets',wallet.id);await DB.remove('cache',wallet.id);state.wallets=state.wallets.filter(w=>w.id!==wallet.id);state.results=state.results.filter(r=>r.walletId!==wallet.id);await assemblePortfolio();renderCurrentView();toast('Carteira removida do navegador.');}return;}
  if(event.target.closest('#dismiss-notice')){state.noticesDismissed=true;$('#provider-notice').style.display='none';return;}
  if(event.target.closest('#open-buy-form')){$('#buy-form-panel').style.display='block';return;}
  if(event.target.closest('#close-buy-form')||event.target.closest('#close-buy-form-2')){$('#buy-form-panel').style.display='none';return;}
  if(event.target.closest('#open-defi-form')){$('#defi-form-panel').style.display='block';return;}
  if(event.target.closest('#close-defi-form')||event.target.closest('#close-defi-form-2')){$('#defi-form-panel').style.display='none';return;}
  if(event.target.closest('#toggle-defi')||event.target.closest('#toggle-defi-settings')){state.settings.includeDefi=!state.settings.includeDefi;await saveSettings();await assemblePortfolio();renderCurrentView();return;}
  const delTrade=event.target.closest('[data-delete-trade]');if(delTrade){await DB.remove('trades',delTrade.dataset.deleteTrade);state.trades=state.trades.filter(t=>t.id!==delTrade.dataset.deleteTrade);renderCosts();toast('Registro removido.');return;}
  const delDefi=event.target.closest('[data-delete-defi]');if(delDefi){await DB.remove('defi',delDefi.dataset.deleteDefi);state.defi=state.defi.filter(d=>d.id!==delDefi.dataset.deleteDefi);await assemblePortfolio();renderDefi();toast('Registro DeFi removido.');return;}
  const period=event.target.closest('[data-period]');if(period){state.period=period.dataset.period;$$('[data-period]').forEach(b=>b.classList.toggle('active',b===period));renderChart();return;}
  if(event.target.closest('#clear-local-data')){if(confirm('Apagar TODOS os dados CoinPortracker deste navegador? Faça um backup antes.')){await DB.clearAll();state.wallets=[];state.results=[];state.transactions=[];state.trades=[];state.defi=[];state.snapshots=[];state.assets=[];await loadState();navigate('dashboard');toast('Dados locais apagados.');}return;}
  if(event.target.closest('#mobile-menu')){$('#sidebar').classList.toggle('open');return;}
});

document.addEventListener('submit',async event=>{
  if(event.target.id==='buy-form'){
    event.preventDefault();const f=new FormData(event.target);const trade={id:id(),type:'buy',asset:String(f.get('asset')).toUpperCase().trim(),quantity:Number(f.get('quantity')),unitPrice:Number(f.get('unitPrice')),networkFee:Number(f.get('networkFee')||0),timestamp:new Date(f.get('date')).getTime(),note:String(f.get('note')||'').trim(),currency:state.currency};
    if(!(trade.quantity>0)||!(trade.unitPrice>=0)||!(trade.networkFee>=0)){toast('Confira quantidade, preço e taxa.','error');return;}
    await DB.put('trades',trade);state.trades.push(trade);renderCosts();toast('Custo de aquisição salvo localmente.');
  }
  if(event.target.id==='defi-form'){
    event.preventDefault();const f=new FormData(event.target);const kind=String(f.get('kind'));const item={id:id(),kind,protocol:String(f.get('protocol')).trim(),network:String(f.get('network')),symbol:String(f.get('symbol')).toUpperCase().trim(),amount:Number(f.get('amount')),price:Number(f.get('unitPrice')||0),unitPrice:Number(f.get('unitPrice')||0),block:String(f.get('block')||'').trim(),timestamp:new Date(f.get('date')).getTime(),txid:String(f.get('txid')||'').trim(),active:true,currency:state.currency};
    if(!(item.amount>0)||!(item.price>=0)){toast('Confira quantidade e preço.','error');return;}
    await DB.put('defi',item);state.defi.push(item);await assemblePortfolio();renderDefi();toast(kind==='reward'?'Recompensa registrada.':'Posição DeFi registrada.');
  }
});

async function saveSettings() {
  state.settings.currency=state.currency;
  await DB.put('settings',{id:'main',value:state.settings,updatedAt:Date.now()});
}

document.addEventListener('click',async event=>{
  if(event.target.closest('#save-settings')){
    state.currency=$('#settings-currency').value;state.settings.currency=state.currency;state.settings.coinGeckoKey=$('#coingecko-key').value.trim();await saveSettings();await assemblePortfolio();renderCurrentView();toast('Preferências salvas no navegador.');
  }
});

bindModal();

(async function init(){
  try {
    await DB.requestPersistentStorage();
    await loadState();
    const persisted=await navigator.storage?.persisted?.().catch(()=>false);
    state.storagePersisted=Boolean(persisted);
    if(persisted) setSync('Armazenamento persistente');
    else setSync('Local-first');
    renderCurrentView();
    if(state.wallets.length) {
      // Cache is rendered immediately; network refresh is user-triggered to avoid silent polling.
      setSync('Cache local carregado');
    }
  } catch(error) { console.error(error);toast(`Falha ao iniciar o banco local: ${error.message}`,'error'); }
})();

window.addEventListener('resize',()=>{if(state.view==='dashboard')renderChart();});
