const DB_NAME = 'coinportracker-local';
const DB_VERSION = 1;
const STORES = ['wallets', 'snapshots', 'trades', 'defi', 'settings', 'cache'];

let dbPromise;
function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const store of STORES) {
        if (!db.objectStoreNames.contains(store)) db.createObjectStore(store, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Não foi possível abrir o banco local.'));
  });
  return dbPromise;
}

export async function all(store) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(store, 'readonly').objectStore(store).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function get(store, id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(store, 'readonly').objectStore(store).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

export async function put(store, record) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(store, 'readwrite').objectStore(store).put(record);
    request.onsuccess = () => resolve(record);
    request.onerror = () => reject(request.error);
  });
}

export async function remove(store, id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const request = db.transaction(store, 'readwrite').objectStore(store).delete(id);
    request.onsuccess = () => resolve(true);
    request.onerror = () => reject(request.error);
  });
}

export async function clearAll() {
  const db = await openDB();
  await Promise.all(STORES.map(store => new Promise((resolve, reject) => {
    const request = db.transaction(store, 'readwrite').objectStore(store).clear();
    request.onsuccess = resolve;
    request.onerror = () => reject(request.error);
  })));
}

export async function exportDatabase() {
  const result = { schema: 1, app: 'CoinPortracker', exportedAt: new Date().toISOString(), data: {} };
  for (const store of STORES) result.data[store] = await all(store);
  return result;
}

export async function importDatabase(payload) {
  if (!payload || payload.app !== 'CoinPortracker' || !payload.data || payload.schema !== 1) {
    throw new Error('Arquivo de backup incompatível ou inválido.');
  }
  const allowed = new Set(STORES);
  for (const [store, records] of Object.entries(payload.data)) {
    if (!allowed.has(store) || !Array.isArray(records)) continue;
    for (const record of records) {
      if (!record || typeof record.id !== 'string') continue;
      await put(store, record);
    }
  }
}

export async function requestPersistentStorage() {
  try {
    if (navigator.storage?.persist) return await navigator.storage.persist();
  } catch { /* browser may refuse persistent storage */ }
  return false;
}
