import test from 'node:test';
import assert from 'node:assert/strict';
import { acquisitionTotals, aggregateAssets, healthScore, periodChange } from '../src/analytics.js';
import { validateAddress } from '../src/providers.js';

test('soma custo de aquisição e separa taxas na moeda selecionada', () => {
  const trades = [
    { type:'buy', quantity:0.5, unitPrice:200000, networkFee:12, currency:'brl' },
    { type:'buy', quantity:2, unitPrice:100, networkFee:1, currency:'usd' }
  ];
  assert.deepEqual(acquisitionTotals(trades,'brl'), { costWithoutFees:100000, fees:12, costWithFees:100012, count:1 });
});

test('agrega o mesmo ativo da mesma rede sem misturar contratos distintos', () => {
  const results = [
    { assets:[{ symbol:'ETH', network:'Ethereum', amount:1, price:100, value:100 }] },
    { assets:[{ symbol:'ETH', network:'Ethereum', amount:2, price:100, value:200 }, { symbol:'ETH', network:'Base', amount:1, price:100, value:100 }] }
  ];
  const result = aggregateAssets(results);
  assert.equal(result.length,2);
  assert.equal(result.find(a=>a.network==='Ethereum').amount,3);
  assert.equal(result.find(a=>a.network==='Base').amount,1);
});

test('saúde do portfólio retorna um score limitado de 0 a 100', () => {
  const result = healthScore([{ value:100 },{ value:100 }]);
  assert.ok(result.score >= 0 && result.score <= 100);
  assert.equal(result.count,2);
});

test('variação de período exige snapshot anterior ao início da janela', () => {
  const now = Date.now();
  const snapshots = [
    { timestamp:now-2*3600000, value:100, values:{brl:100} },
    { timestamp:now-30*60000, value:120, values:{brl:120} }
  ];
  const result = periodChange(snapshots,110,'1H','brl');
  assert.equal(result.amount,10);
  assert.equal(result.percent,10);
  assert.equal(periodChange(snapshots,110,'24H','brl'),null);
});

test('validação dos principais formatos de endereço', () => {
  assert.doesNotThrow(()=>validateAddress({ network:'bitcoin', address:'1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa' }));
  assert.doesNotThrow(()=>validateAddress({ network:'ethereum', address:'0x0000000000000000000000000000000000000000' }));
  assert.doesNotThrow(()=>validateAddress({ network:'solana', address:'11111111111111111111111111111111' }));
  assert.throws(()=>validateAddress({ network:'ethereum', address:'not-an-address' }));
});
